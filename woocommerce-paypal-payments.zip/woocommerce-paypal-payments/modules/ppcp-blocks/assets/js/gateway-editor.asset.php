<?php

namespace {
    return array('dependencies' => array(), 'version' => '6a8b65f75f02d040e607');
}
