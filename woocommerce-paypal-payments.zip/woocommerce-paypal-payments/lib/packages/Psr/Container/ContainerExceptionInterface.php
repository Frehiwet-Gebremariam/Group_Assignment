<?php

namespace WooCommerce\PayPalCommerce\Vendor\Psr\Container;

/**
 * Base interface representing a generic exception in a container.
 */
interface ContainerExceptionInterface
{
}
