<?php

namespace {
    return array('dependencies' => array(), 'version' => 'a3ec51301c5b1add93fb');
}
