<?php

PUM_Site_Popups::preload_popup_by_id_if_enabled( get_the_ID() );

get_header();

get_footer();
