<?php

namespace {
    return array('dependencies' => array(), 'version' => '935b49f0dac69602c3a9');
}
