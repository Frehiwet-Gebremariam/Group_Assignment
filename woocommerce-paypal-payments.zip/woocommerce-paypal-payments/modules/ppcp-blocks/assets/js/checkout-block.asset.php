<?php

namespace {
    return array('dependencies' => array('react', 'wc-blocks-registry', 'wp-element', 'wp-i18n'), 'version' => '7a8b41bbe53c98888494');
}
