<<?php $module->tag( 'div' ); ?> <?php $module->render_attributes(); ?>>
	<?php $module->render_children(); ?>
</<?php $module->tag( 'div' ); ?>>
