<input
type="hidden"
name="{{data.name}}"
value="{{data.value}}"
class="<# if ( data.field.className ) { #> {{data.field.className}}<# } #>"
/>
