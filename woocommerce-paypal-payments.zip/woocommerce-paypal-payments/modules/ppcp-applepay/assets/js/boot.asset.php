<?php

namespace {
    return array('dependencies' => array(), 'version' => '3a36245f8beef10cdc72');
}
