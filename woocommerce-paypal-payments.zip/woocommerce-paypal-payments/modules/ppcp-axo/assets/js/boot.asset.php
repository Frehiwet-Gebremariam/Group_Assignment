<?php

namespace {
    return array('dependencies' => array(), 'version' => 'aa483b104b7be73d624a');
}
