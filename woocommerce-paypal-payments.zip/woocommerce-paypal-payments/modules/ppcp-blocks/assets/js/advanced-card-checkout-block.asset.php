<?php

namespace {
    return array('dependencies' => array('react', 'wc-blocks-registry', 'wp-element', 'wp-i18n'), 'version' => '556d6d5ee27642013b3e');
}
