<?php return array('version' => 'fad4b11b50e4f77281f7');
