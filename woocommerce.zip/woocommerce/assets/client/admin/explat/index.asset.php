<?php return array('dependencies' => array('react', 'wp-api-fetch', 'wp-hooks'), 'version' => '5821f47b67e1590fa42a');
