<?php

namespace WooCommerce\PayPalCommerce\Vendor\Psr\Container;

/**
 * No entry was found in the container.
 */
interface NotFoundExceptionInterface extends \WooCommerce\PayPalCommerce\Vendor\Psr\Container\ContainerExceptionInterface
{
}
