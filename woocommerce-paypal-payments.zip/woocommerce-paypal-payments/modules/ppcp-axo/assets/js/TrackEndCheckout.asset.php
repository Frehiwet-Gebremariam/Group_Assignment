<?php

namespace {
    return array('dependencies' => array(), 'version' => '75b77bcde30461da7953');
}
