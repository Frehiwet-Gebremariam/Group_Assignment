<?php

namespace {
    return array('dependencies' => array(), 'version' => 'f3364da76f1447684b3c');
}
