<?php

namespace {
    return array('dependencies' => array(), 'version' => '3b967833b80a0fcf3298');
}
