<?php

namespace {
    return array('dependencies' => array('wc-blocks-registry', 'wp-data', 'wp-element', 'wp-i18n'), 'version' => 'f48a8a3ee6c525fa7523');
}
