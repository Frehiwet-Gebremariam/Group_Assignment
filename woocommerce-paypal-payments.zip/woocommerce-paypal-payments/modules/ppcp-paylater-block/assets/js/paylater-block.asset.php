<?php

namespace {
    return array('dependencies' => array('react', 'wp-block-editor', 'wp-blocks', 'wp-components', 'wp-element', 'wp-i18n'), 'version' => '021ab76e50fdf98f8e76');
}
