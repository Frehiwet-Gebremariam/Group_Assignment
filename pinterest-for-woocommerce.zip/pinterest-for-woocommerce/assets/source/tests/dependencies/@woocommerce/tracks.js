export const recordEvent = jest.fn().mockName( 'recordEvent' );

export default recordEvent;
