const Example = () => {
	return <div>Example</div>;
};

export default Example;
