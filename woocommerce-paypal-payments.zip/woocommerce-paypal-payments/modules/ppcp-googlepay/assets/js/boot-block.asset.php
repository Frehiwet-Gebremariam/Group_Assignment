<?php

namespace {
    return array('dependencies' => array('wc-blocks-registry', 'wp-element', 'wp-i18n'), 'version' => 'ce7bbec97d329557d28c');
}
