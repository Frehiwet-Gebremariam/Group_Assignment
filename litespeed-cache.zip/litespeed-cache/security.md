# Security Policy

## Reporting Security Bugs

We take security seriously. Please report potential vulnerabilities found in the LiteSpeed Cache plugin's source code via email to `support@litespeedtech.com` or open a ticket from your LiteSpeed Client Area.

Please see [Reporting Vulnerabilities](https://www.litespeedtech.com/report-security-bugs) for more information.
